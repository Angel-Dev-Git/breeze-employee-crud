<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Add Employee details') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-xl">
                    <form method="POST" action="{{route('employees.store')}}" id="employee-form" enctype="multipart/form-data">
                        @csrf

                        <div class="row mb-4">
                            <div class="col">
                            <label>Name</label>
                            <input type="text" id="name" name="name" placeholder="Enter employee name"class="form-control" value="{{old('name')}}"/>
                            <x-input-error :messages="$errors->first('name')" class="mt-2" />

                            </div>
                        </div>
                          <div class="row mb-4">
                            <div class="col">
                            <label>Email</label>
                            <input type="text" id="email" name="email" placeholder="Enter employee mail"class="form-control" value="{{old('email')}}"/>
                             <x-input-error :messages="$errors->first('email')" class="mt-2" />

                        </div>
                        </div>
                         <div class="row mb-4">
                            <div class="col">
                                <label>Phone no</label>
                                <input type="text" id="phone" name="phone" placeholder="Enter employee phone no"class="form-control" value="{{old('phone')}}"/>
                                <x-input-error :messages="$errors->first('phone')" class="" />

                            </div>
                        </div>
                         <div class="row mb-4">
                            <div class="col">
                                <label>Profile Pic</label>
                                <input type="file" id="image" name="image"class="form-control" value="{{old('phone')}}"/>
                                 <x-input-error :messages="$errors->first('image')" class="" />
                            </div>
                         </div>

                          <div class="row mb-4">
                            <div class="col">
                                <label>Position</label>
                                <select name="position" class="form-control">
                                    <option value="">Select position</option>
                                    <option value="manager">Manager</option>
                                    <option value="developer">Developer</option>
                                    <option value="hr">Hr</option>

                                </select>
                                 <x-input-error :messages="$errors->first('position')" class="" />
                            </div>
                         </div>

                          <div class="row mb-4">
                            <div class="col">
                                <label>Skills</label>
                                 <select name="skills[]" id="skills" class="form-control" multiple>
                                    <option value="laravel">Laravel</option>
                                    <option value="react">React</option>
                                    <option value="vue">Vue.js</option>
                                    <option value="node">Node.js</option>
                                    <option value="sql">SQL</option>
                                </select>
                                 <x-input-error :messages="$errors->first('skills')" class="" />
                            </div>
                         </div>

                        <div>
                            <button type="submit" class="btn btn-primary">Add Employee details </button>
                        </div>
                    </form>
                </div>
            </div>

          
        </div>
    </div>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
    $(document).ready(function() {
        $('#skills').select2({
            placeholder: "Select skills"
        });
    });
</script>
</x-app-layout>

