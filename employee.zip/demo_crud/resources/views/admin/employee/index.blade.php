<x-app-layout>
    <x-slot name="header">
          <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Employee List') }}
        </h2>
        <a href="{{route('employees.create')}}" class="btn btn-success btn-sm mb-3">Add Employee</a>
        <table class="table" id="employee-table">
            <thead>
                <tr>
                    <th>ID</th>
                     <th>Image</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Contact no</th>
                    <th>Position</th>
                    <th>Action</th>
                </tr>
            </thead>
        </table>
    </x-slot>

    <script>

        $(function(){
            $('#employee-table').DataTable({
                processing:true,
                serverSide:true,
                ajax:"{{route('employees.index')}}",
                columns:[
                    {data:'id',name:'id'},
                    {data:'image',name:'image',orderable:false,searchable:false},
                    {data:'name',name:'name'},
                    {data:'email',name:'email'},
                    {data:'phone_no',name:'phone_no'},
                    {data:'position',name:'position'},
                    {data:'action',name:'action',orderable:false,searchable:false},
                ]
            })
        });

        //To perform delete functionality
        $(document).on('click','.delete-btn',function(){
            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to revert this!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, delete it!"
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: "{{ route('employees.index') }}/"  + $(this).data("id"),
                        type: 'DELETE',
                        data: { _token: "{{ csrf_token() }}" },
                        success: function(response) {
                            $('#employee_table').DataTable().ajax.reload();
                            Swal.fire(
                                "Deleted!",
                                "Employee has been deleted.",
                                "success"
                            );
                        },
                        error: function(xhr) {
                            Swal.fire(
                                "Failed!",
                                "Something went wrong.",
                                "error"
                            );
                        }
                    });
                }
                });
            });


 </script>
</x-app-layout>