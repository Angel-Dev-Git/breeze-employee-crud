<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Update Employee details') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-xl">
                    <form method="POST" action="{{route('employees.update',$employee->id)}}" id="employee-form" enctype="multipart/form-data">
                        @csrf
         @method('put')
                        <div class="row mb-4">
                            <div class="col">
                            <label>Name</label>
                            <input type="text" id="name" name="name" placeholder="Enter employee name"class="form-control" value="{{$employee->name ?? old('name')}}"/>
                                                                    <x-input-error :messages="$errors->first('name')" class="mt-2" />

                            </div>
                        </div>
                          <div class="row mb-4">
                            <div class="col">
                            <label>Email</label>
                            <input type="text" id="email" name="email" placeholder="Enter employee mail"class="form-control" value="{{$employee->email ?? old('email')}}"/>
                                         <x-input-error :messages="$errors->first('email')" class="mt-2" />

                        </div>
                        </div>
                         <div class="row mb-4">
                            <div class="col">
                                <label>Phone no</label>
                                <input type="text" id="phone" name="phone" placeholder="Enter employee phone no"class="form-control" value="{{$employee->phone ?? old('phone')}}"/>
                                <x-input-error :messages="$errors->first('phone')" class="" />

                            </div>
                        </div>
                         <div class="row mb-4">
                            <div class="col">
                                <label>Profile Pic</label>
                                @if($employee->profile_pic)
                                <img src="{{asset('storage/'.$employee->profile_pic)}}" width="50" />
                                @else
                                <input type="file" id="image" name="image"class="form-control" value="{{old('phone')}}"/>
                                 <x-input-error :messages="$errors->first('image')" class="" />
                                    @endif
                            </div>
                         </div>

                          <div class="row mb-4">
                            <div class="col">
                                <label>Position</label>
                                <select name="position" class="form-control">
                                   <option value="manager" {{ old('position', $employee->position) === 'manager' ? 'selected' : '' }}>Manager</option>
                                    <option value="developer" {{ old('position', $employee->position) === 'developer' ? 'selected' : '' }}>Developer</option>
                                    <option value="hr" {{ old('position', $employee->position) === 'hr' ? 'selected' : '' }}>Hr</option>
                                </select>
                                 <x-input-error :messages="$errors->first('position')" class="" />
                            </div>
                         </div>

                        <div class="row mb-4">
                            <div class="col">
                                <label>Skills</label>
                                <select name="skills[]" id="skills" class="form-control" multiple>
                                   @php
                                        $selectedSkills = old('skills') ?? (is_array($employee->skills) ? $employee->skills : json_decode($employee->skills ?? '[]', true));
                                    @endphp
                                    @foreach(['laravel','react','vue','node','sql'] as $skill)
                                        <option value="{{ $skill }}" {{ in_array($skill, $selectedSkills) ? 'selected' : '' }}>
                                            {{ ucfirst($skill) }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div>
                            <button type="submit" class="btn btn-primary">Update Employee details </button>
                        </div>
                    </form>
                </div>
            </div>

          
        </div>
    </div>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
    $(document).ready(function() {
        $('#skills').select2({
            placeholder: "Select skills"
        });
    });
</script>
</x-app-layout>
