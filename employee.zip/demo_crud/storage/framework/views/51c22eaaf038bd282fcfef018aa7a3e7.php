<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
          <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Employee List')); ?>

        </h2>
        <a href="<?php echo e(route('employees.create')); ?>" class="btn btn-success btn-sm mb-3">Add Employee</a>
        <table class="table" id="employee-table">
            <thead>
                <tr>
                    <th>ID</th>
                     <th>Image</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Contact no</th>
                    <th>Position</th>
                    <th>Action</th>
                </tr>
            </thead>
        </table>
     <?php $__env->endSlot(); ?>

    <script>

        $(function(){
            $('#employee-table').DataTable({
                processing:true,
                serverSide:true,
                ajax:"<?php echo e(route('employees.index')); ?>",
                columns:[
                    {data:'id',name:'id'},
                    {data:'image',name:'image',orderable:false,searchable:false},
                    {data:'name',name:'name'},
                    {data:'email',name:'email'},
                    {data:'phone_no',name:'phone_no'},
                    {data:'position',name:'position'},
                    {data:'action',name:'action',orderable:false,searchable:false},
                ]
            })
        });

        //To perform delete functionality
        $(document).on('click','.delete-btn',function(){
            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to revert this!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, delete it!"
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: "<?php echo e(route('employees.index')); ?>/"  + $(this).data("id"),
                        type: 'DELETE',
                        data: { _token: "<?php echo e(csrf_token()); ?>" },
                        success: function(response) {
                            $('#employee_table').DataTable().ajax.reload();
                            Swal.fire(
                                "Deleted!",
                                "Employee has been deleted.",
                                "success"
                            );
                        },
                        error: function(xhr) {
                            Swal.fire(
                                "Failed!",
                                "Something went wrong.",
                                "error"
                            );
                        }
                    });
                }
                });
            });


 </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\demo_crud\resources\views/admin/employee/index.blade.php ENDPATH**/ ?>