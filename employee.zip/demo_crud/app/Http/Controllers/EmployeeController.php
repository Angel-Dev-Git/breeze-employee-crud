<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;
use Auth;
use DataTables;
use Illuminate\Validation\Rule;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $employee = Employee::latest();
        if($request->ajax()){
            return DataTables::of($employee)
            ->addColumn('action',function($row){
                return '<a href="'.route('employees.edit',$row->id).'" class="btn btn-sm btn-primary">Edit</a> 
                <button class="btn btn-sm btn-danger delete-btn" data-id="'.$row->id.'">Delete</button>';
            })
             ->editColumn('name', function ($row) {
                return '<span style="font: weight 400px;">$row->name</span>';
            })
           ->editColumn('image', function ($row) {
                $imagePath = asset("storage/{$row->profile_pic}");
                return '<img src="' . $imagePath . '" width="50">';
            })
            ->rawColumns(['action','image'])
            ->make('true');
        }

        return view('admin.employee.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admin.employee.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|min:3|max:50',
            'email' => 'required|email|unique:employees,email',
            'phone' => ['required','regex:/^\+\d{8,15}$/'],
            'position' => 'required|in:manager,developer,hr',
            'image' => 'nullable|image|mimes:jpg,png,svg|max:2048',
            'skills' => 'nullable|array',
            'skills.*' => 'in:laravel,react,vue,node,sql',

        ]);
        $data = $request->except(['image','skills']);
        if($request->hasFile('image')){
            $data['profile_pic'] =  $request->file('image')->store('employees','public');
        }
        if($request->skills){
            $data['skills'] = json_encode($request->skills);
        }
        Employee::create($data);
       return redirect()->route('employees.index')->with('status', 'employee-created');

    }

    /**
     * Display the specified resource.
     */
    public function show(Employee $employee)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Employee $employee)
    {
        return view('admin.employee.edit',compact('employee'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Employee $employee)
    {
       $validated =  $request->validate([
             'name' => 'required|string|min:3|max:50',
            'email' => [
                'required',
                'email',
                Rule::unique('employees', 'email')->ignore($employee->id),
            ],
            'phone' => ['required','regex:/^\+\d{8,15}$/'],
            'position' => 'required|in:manager,developer,hr',
            'image' => 'nullable|image|mimes:jpg,png,svg|max:2048',
            'skills' => 'nullable|array',
            'skills.*' => 'in:laravel,react,vue,node,sql',
        ]);
        $data = $request->except('image');
        if($request->hasFile('image')){
            if($employee->profile_pic && Storage::disk('public')->exists($employee->profile_pic)){
                Storage::disk('public')->delete($employee->profile_pic);
            }

            $data['profile_pic'] = $request->file('image')->store('employees','public');
        }
         if($request->skills){
            $data['skills'] = json_encode($request->skills);
        }
        $employee->update($data);
        return redirect()->route('employees.index')->with('success','Employees details updated successfully!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Employee $employee)
    {
        $employee->delete();
        return response()->json(['success' => true]);
    }
}
